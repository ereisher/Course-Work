This document contains a step by step method to go through the database.

1. Go to homepage.
	The homepage has three links to other pages- methods, results and NCBI
2. Click on methods.
	There are two downloadble links to the experimental methods- Bacterial
	Growth Curve and Virus Hunting Manual 
	Feel free to download them if you wish
3. Go back to homepage and click on results.
	The table shows the results of the spectrometer reading for the 
	bacterial growth curve experiment
	The Novel Phage FASTA sequence can be downloaded for use in NCBI's BLAST4. Go back to homepage and click on NCBI
	NCBI's BLAST page is there for analysis of FASTA sequences and for 
	alignment 

***ALL PHOTOS ARE MY OWN***
