--Creating specReading table for the results
CREATE TABLE specReading(
	Time VARCHAR(5),
	specValue DECIMAL(5,3)
);
