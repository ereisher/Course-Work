-- Insert Statements for the dump file
INSERT INTO specReading VALUES("12:30","0.046");
INSERT INTO specReading VALUES("1:20","0.051");
INSERT INTO specReading VALUES("1:50","0.051");
INSERT INTO specReading VALUES("2:20","0.055");
INSERT INTO specReading VALUES("2:50","0.047");
INSERT INTO specReading VALUES("3:20","0.143");
INSERT INTO specReading VALUES("3:50","0.228");
INSERT INTO specReading VALUES("4:20","0.398");
INSERT INTO specReading VALUES("4:50","0.616");
INSERT INTO specReading VALUES("5:20","1.08");
